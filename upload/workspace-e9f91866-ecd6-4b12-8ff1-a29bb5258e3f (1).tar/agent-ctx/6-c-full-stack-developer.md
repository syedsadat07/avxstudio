# Task 6-c: AURAVIX Contact Page

## Agent: full-stack-developer

## Summary
Built the complete Contact page component for AURAVIX with contact form, contact information, map placeholder, and FAQ sections.

## Files Created/Modified
- **Created:** `/src/components/contact/ContactPage.tsx` - Main Contact page component
- **Created:** `/src/app/api/contacts/route.ts` - API endpoint for contact form submissions
- **Modified:** `/src/app/page.tsx` - Added ContactPage import and routing for 'contact' page

## Key Decisions
- Used lg:col-span-3 / lg:col-span-2 split for form/info layout (5-column grid) for better proportions
- Form always shows success toast and resets even if API fails, per requirement
- Map placeholder uses dark gradient with grid lines, road-like lines, and animated bouncing MapPin
- FAQ uses shadcn Accordion with gold hover effect on triggers
- Pinterest icon replaced with Clock icon since Lucide doesn't have a Pinterest icon
- Social media icons use border-radius circles with gold hover transition

## Component Structure
1. Hero Section - Dark gradient background with gold accents
2. Contact Form + Info - Two-column layout (form left, info right)
3. Map Placeholder - Gradient card with animated pin marker
4. FAQ Section - Accordion with 5 questions

## API
- POST /api/contacts
- Validates: fullName, email, subject, message (required)
- Email format validation
- Returns reference number on success
